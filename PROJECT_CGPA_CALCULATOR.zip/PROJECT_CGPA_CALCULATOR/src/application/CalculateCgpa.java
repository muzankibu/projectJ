package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CalculateCgpa extends Application{

	
	public void start(Stage pstage) throws Exception {
		
		Button starter=new Button("Click here to calculate your CGPA");
		
		starter.setOnAction(new EventHandler<ActionEvent>() {
			
			
			public void handle(ActionEvent arg0) {
				
				Label head=new Label("CGPA CALCULATOR\n\n(Do not leave any box empty)");
				
				Label stdName=new Label("NAME :");
				TextField t1=new TextField();
				
				Label stdId=new Label("ID :");
				TextField t2=new TextField();
				
				
				
				
				Label crs1=new Label("Course 1: ");	
				Label nm1=new Label("name");
				ComboBox<String> first1=new ComboBox<String>();
				
				first1.getItems().add("NONE");
				first1.getItems().add("ENG 102 Introduction to Composition");
			    first1.getItems().add("ENG 103 Intermediate Composition");
				first1.getItems().add("ENG 111 Public Speaking");
				first1.getItems().add("PHI 101 Introduction to Philosophy");
				first1.getItems().add("PHI 104 Introduction to Ethics");
				first1.getItems().add("LBA 101 Bangladesh Culture and Heritage");
				first1.getItems().add("LBA 102 Introduction to World Civilization");
				first1.getItems().add("POL 101 Introduction to Political Science");
				first1.getItems().add("POL 104 Introduction to Governance");
				first1.getItems().add("ECO 101 Introduction to Microeconomics");
				first1.getItems().add("ECO 104 Introduction to Macroeconomics");
				first1.getItems().add("SOC 101 Introduction to Sociology");
				first1.getItems().add("ENV 203/ GEO 205 Introduction to Bangladesh Geography");
				first1.getItems().add("ANT 101 Introduction to Anthropology");
				first1.getItems().add("BIO 103 Biology I");
				first1.getItems().add("MAT 116 Pre-Calculus");
				first1.getItems().add("MAT 120 Calculus-I");
				first1.getItems().add("MAT 125 Linear Algebra");
				first1.getItems().add("MAT 130 Calculus II");
				first1.getItems().add("MAT 250 Calculus III");
				first1.getItems().add("MAT 350 Engineering Mathematics");
				first1.getItems().add("MAT 361 Probability and Statistics");
				first1.getItems().add("PHY 107 Physics I");
				first1.getItems().add("PHY 108 Physics II");
				first1.getItems().add("CHE 101 Chemistry I");
				first1.getItems().add("EEE 452 Engineering Economics");
				first1.getItems().add("CEE 110 Engineering Drawing (EEE 154)");
				first1.getItems().add("CSE 115 Programming Language I");
				first1.getItems().add("CSE 115L Programming Language I Lab");
				first1.getItems().add("CSE 215 Programming Language II");
				first1.getItems().add("CSE 215L Programming Language II Lab");
				first1.getItems().add("CSE 173 Discrete Mathematics");
				first1.getItems().add("CSE 225 Data Structures and Algorithms");
				first1.getItems().add("CSE 225L Data Structures and Algorithms Lab");
				first1.getItems().add("CSE 231 Digital Logic design");
				first1.getItems().add("CSE 231L Digital Logic design Lab");
				first1.getItems().add("CSE 299 Junior Design Course");
				first1.getItems().add("EEE 141 Electrical Circuits I");
				first1.getItems().add("EEE 141L Electrical Circuits I Lab");
				first1.getItems().add("EEE 111/ ETE 111 Analog Electronics-I");
				first1.getItems().add("EEE 111L/ ETE 111L Analog Electronics-I Lab");
				first1.getItems().add("CSE 311 Database Systems");
				first1.getItems().add("CSE 311L Database Systems Lab");
				first1.getItems().add("CSE 323 Operating Systems Design");
				first1.getItems().add("CSE 327 Software Engineering");
				first1.getItems().add("CSE 331 Microprocessor Interfacing & Embedded System");
				first1.getItems().add("CSE 331L Microprocessor Interfacing & Embedded System Lab");
				first1.getItems().add("CSE 332 Computer Organization and Architecture");
				first1.getItems().add("CSE 373 Design and Analysis of Algorithms");
				first1.getItems().add("CSE 325/CSE 425 Concepts of Programming Language");
				first1.getItems().add("CSE 498/EEE 498/ETE 498 Internship/Co-op/Directed Research");
				first1.getItems().add("CSE 499A/EEE499A/ETE499A – Senior Design I");
				first1.getItems().add("CSE 499B/EEE499B/ETE499B – Senior Design II");
				first1.getItems().add("CSE 417 Numerical Methods");
				first1.getItems().add("CSE 401 Advanced Programming Techniques");
				first1.getItems().add("CSE 418 Computer Graphics");
				first1.getItems().add("CSE 426 Compiler Constructions");
				first1.getItems().add("CSE 473 Theory of Computation");
				first1.getItems().add("CSE 411 Advanced Database Systems");
				first1.getItems().add("CSE 424 Object-Oriented Software Developments");
				first1.getItems().add("CSE 427 Software Quality Assurances & Testing");
				first1.getItems().add("CSE 428 Software Process Management");
				first1.getItems().add("CSE 429 Software System Architecture");
				first1.getItems().add("CSE 492 Special Topics");
				first1.getItems().add("CSE 422 Modelling and Simulation");
				first1.getItems().add("CSE 438 Data Communication & Network");
				first1.getItems().add("CSE 482 Internet and Web Technology");
				first1.getItems().add("CSE 485 Digital Signal Processing");
				first1.getItems().add("CSE 486 Mobile and Wireless Application Development");
				first1.getItems().add("CSE 493 Special Topics");
				first1.getItems().add("CSE 433 Advanced Computer Architecture");
				first1.getItems().add("CSE 435 Introduction to VLSI Design");
				first1.getItems().add("CSE 413 Verilog HDL: Modelling, Simulation and synthesis");
				first1.getItems().add("CSE 414 Advanced Chip Design Methodology and Optimiza.using HDL");
				first1.getItems().add("CSE 494 Special Topics");
				first1.getItems().add("CSE 419 Data Mining");
				first1.getItems().add("CSE 440 Artificial Intelligence");
				first1.getItems().add("CSE 445 Machine Learning");
				first1.getItems().add("CSE 465 Pattern Recognition and Neural Network");
				first1.getItems().add("CSE 467 Digital Image Processing");
				first1.getItems().add("CSE 468 Computer Vision");
				first1.getItems().add("CSE 470 Theory of Fuzzy Systems");
				first1.getItems().add("CSE 495 Special Topics");
				first1.getItems().add("CSE 446 Introductions to Bioinformatics");
				first1.getItems().add("CSE 447 Molecular Biology");
				first1.getItems().add("CSE 448 Genome Sequence & Analysis");
				first1.getItems().add("CSE 449 Structural Bioinformatics");
				first1.getItems().add("CSE 496 Special Topics");
				
				
				
				Label cr1=new Label("Credit");
				ComboBox<String> first2=new ComboBox<String>();
				first2.getItems().add("0");
				first2.getItems().add("1");
				first2.getItems().add("1.5");
				first2.getItems().add("3");
				
				Label grd1=new Label("Grade");
				ComboBox<String> first3=new ComboBox<String>();
				
				
				first3.getItems().add("A");
				first3.getItems().add("A-");
				first3.getItems().add("B+");
				first3.getItems().add("B");
				first3.getItems().add("B-");
				first3.getItems().add("C+");
				first3.getItems().add("C");
				first3.getItems().add("C-");
				first3.getItems().add("D+");
				first3.getItems().add("D");
				first3.getItems().add("F");
				first3.getItems().add("NONE");
				
				
				////////////////////
				////////////////
				
				Label crs2=new Label("Course 2: ");	
				Label nm2=new Label("name");
				ComboBox<String> second1=new ComboBox<String>();
				
				second1.getItems().add("NONE");
				second1.getItems().add("ENG 102 Introduction to Composition");
			    second1.getItems().add("ENG 103 Intermediate Composition");
				second1.getItems().add("ENG 111 Public Speaking");
				second1.getItems().add("PHI 101 Introduction to Philosophy");
				second1.getItems().add("PHI 104 Introduction to Ethics");
				second1.getItems().add("LBA 101 Bangladesh Culture and Heritage");
				second1.getItems().add("LBA 102 Introduction to World Civilization");
				second1.getItems().add("POL 101 Introduction to Political Science");
				second1.getItems().add("POL 104 Introduction to Governance");
				second1.getItems().add("ECO 101 Introduction to Microeconomics");
				second1.getItems().add("ECO 104 Introduction to Macroeconomics");
				second1.getItems().add("SOC 101 Introduction to Sociology");
				second1.getItems().add("ENV 203/ GEO 205 Introduction to Bangladesh Geography");
				second1.getItems().add("ANT 101 Introduction to Anthropology");
				second1.getItems().add("BIO 103 Biology I");
				second1.getItems().add("MAT 116 Pre-Calculus");
				second1.getItems().add("MAT 120 Calculus-I");
				second1.getItems().add("MAT 125 Linear Algebra");
				second1.getItems().add("MAT 130 Calculus II");
				second1.getItems().add("MAT 250 Calculus III");
				second1.getItems().add("MAT 350 Engineering Mathematics");
				second1.getItems().add("MAT 361 Probability and Statistics");
				second1.getItems().add("PHY 107 Physics I");
				second1.getItems().add("PHY 108 Physics II");
				second1.getItems().add("CHE 101 Chemistry I");
				second1.getItems().add("EEE 452 Engineering Economics");
				second1.getItems().add("CEE 110 Engineering Drawing (EEE 154)");
				second1.getItems().add("CSE 115 Programming Language I");
				second1.getItems().add("CSE 115L Programming Language I Lab");
				second1.getItems().add("CSE 215 Programming Language II");
				second1.getItems().add("CSE 215L Programming Language II Lab");
				second1.getItems().add("CSE 173 Discrete Mathematics");
				second1.getItems().add("CSE 225 Data Structures and Algorithms");
				second1.getItems().add("CSE 225L Data Structures and Algorithms Lab");
				second1.getItems().add("CSE 231 Digital Logic design");
				second1.getItems().add("CSE 231L Digital Logic design Lab");
				second1.getItems().add("CSE 299 Junior Design Course");
				second1.getItems().add("EEE 141 Electrical Circuits I");
				second1.getItems().add("EEE 141L Electrical Circuits I Lab");
				second1.getItems().add("EEE 111/ ETE 111 Analog Electronics-I");
				second1.getItems().add("EEE 111L/ ETE 111L Analog Electronics-I Lab");
				second1.getItems().add("CSE 311 Database Systems");
				second1.getItems().add("CSE 311L Database Systems Lab");
				second1.getItems().add("CSE 323 Operating Systems Design");
				second1.getItems().add("CSE 327 Software Engineering");
				second1.getItems().add("CSE 331 Microprocessor Interfacing & Embedded System");
				second1.getItems().add("CSE 331L Microprocessor Interfacing & Embedded System Lab");
				second1.getItems().add("CSE 332 Computer Organization and Architecture");
				second1.getItems().add("CSE 373 Design and Analysis of Algorithms");
				second1.getItems().add("CSE 325/CSE 425 Concepts of Programming Language");
				second1.getItems().add("CSE 498/EEE 498/ETE 498 Internship/Co-op/Directed Research");
				second1.getItems().add("CSE 499A/EEE499A/ETE499A – Senior Design I");
				second1.getItems().add("CSE 499B/EEE499B/ETE499B – Senior Design II");
				second1.getItems().add("CSE 417 Numerical Methods");
				second1.getItems().add("CSE 401 Advanced Programming Techniques");
				second1.getItems().add("CSE 418 Computer Graphics");
				second1.getItems().add("CSE 426 Compiler Constructions");
				second1.getItems().add("CSE 473 Theory of Computation");
				second1.getItems().add("CSE 411 Advanced Database Systems");
				second1.getItems().add("CSE 424 Object-Oriented Software Developments");
				second1.getItems().add("CSE 427 Software Quality Assurances & Testing");
				second1.getItems().add("CSE 428 Software Process Management");
				second1.getItems().add("CSE 429 Software System Architecture");
				second1.getItems().add("CSE 492 Special Topics");
				second1.getItems().add("CSE 422 Modelling and Simulation");
				second1.getItems().add("CSE 438 Data Communication & Network");
				second1.getItems().add("CSE 482 Internet and Web Technology");
				second1.getItems().add("CSE 485 Digital Signal Processing");
				second1.getItems().add("CSE 486 Mobile and Wireless Application Development");
				second1.getItems().add("CSE 493 Special Topics");
				second1.getItems().add("CSE 433 Advanced Computer Architecture");
				second1.getItems().add("CSE 435 Introduction to VLSI Design");
				second1.getItems().add("CSE 413 Verilog HDL: Modelling, Simulation and synthesis");
				second1.getItems().add("CSE 414 Advanced Chip Design Methodology and Optimiza.using HDL");
				second1.getItems().add("CSE 494 Special Topics");
				second1.getItems().add("CSE 419 Data Mining");
				second1.getItems().add("CSE 440 Artificial Intelligence");
				second1.getItems().add("CSE 445 Machine Learning");
				second1.getItems().add("CSE 465 Pattern Recognition and Neural Network");
				second1.getItems().add("CSE 467 Digital Image Processing");
				second1.getItems().add("CSE 468 Computer Vision");
				second1.getItems().add("CSE 470 Theory of Fuzzy Systems");
				second1.getItems().add("CSE 495 Special Topics");
				second1.getItems().add("CSE 446 Introductions to Bioinformatics");
				second1.getItems().add("CSE 447 Molecular Biology");
				second1.getItems().add("CSE 448 Genome Sequence & Analysis");
				second1.getItems().add("CSE 449 Structural Bioinformatics");
				second1.getItems().add("CSE 496 Special Topics");
				
				
				
				Label cr2=new Label("Credit");
				ComboBox<String> second2=new ComboBox<String>();
				second2.getItems().add("0");
				second2.getItems().add("1");
				second2.getItems().add("1.5");
				second2.getItems().add("3");
				
				Label grd2=new Label("Grade");
				ComboBox<String> second3=new ComboBox<String>();
				
				
				second3.getItems().add("A");
				second3.getItems().add("A-");
				second3.getItems().add("B+");
				second3.getItems().add("B");
				second3.getItems().add("B-");
				second3.getItems().add("C+");
				second3.getItems().add("C");
				second3.getItems().add("C-");
				second3.getItems().add("D+");
				second3.getItems().add("D");
				second3.getItems().add("F");
				second3.getItems().add("NONE");
				
				/////////////////////
				////////////////////
				
				
				Label crs3=new Label("Course 3: ");	
				Label nm3=new Label("name");
				ComboBox<String> third1=new ComboBox<String>();
				
				third1.getItems().add("NONE");
				third1.getItems().add("ENG 102 Introduction to Composition");
			    third1.getItems().add("ENG 103 Intermediate Composition");
				third1.getItems().add("ENG 111 Public Speaking");
				third1.getItems().add("PHI 101 Introduction to Philosophy");
				third1.getItems().add("PHI 104 Introduction to Ethics");
				third1.getItems().add("LBA 101 Bangladesh Culture and Heritage");
				third1.getItems().add("LBA 102 Introduction to World Civilization");
				third1.getItems().add("POL 101 Introduction to Political Science");
				third1.getItems().add("POL 104 Introduction to Governance");
				third1.getItems().add("ECO 101 Introduction to Microeconomics");
				third1.getItems().add("ECO 104 Introduction to Macroeconomics");
				third1.getItems().add("SOC 101 Introduction to Sociology");
				third1.getItems().add("ENV 203/ GEO 205 Introduction to Bangladesh Geography");
				third1.getItems().add("ANT 101 Introduction to Anthropology");
				third1.getItems().add("BIO 103 Biology I");
				third1.getItems().add("MAT 116 Pre-Calculus");
				third1.getItems().add("MAT 120 Calculus-I");
				third1.getItems().add("MAT 125 Linear Algebra");
				third1.getItems().add("MAT 130 Calculus II");
				third1.getItems().add("MAT 250 Calculus III");
				third1.getItems().add("MAT 350 Engineering Mathematics");
				third1.getItems().add("MAT 361 Probability and Statistics");
				third1.getItems().add("PHY 107 Physics I");
				third1.getItems().add("PHY 108 Physics II");
				third1.getItems().add("CHE 101 Chemistry I");
				third1.getItems().add("EEE 452 Engineering Economics");
				third1.getItems().add("CEE 110 Engineering Drawing (EEE 154)");
				third1.getItems().add("CSE 115 Programming Language I");
				third1.getItems().add("CSE 115L Programming Language I Lab");
				third1.getItems().add("CSE 215 Programming Language II");
				third1.getItems().add("CSE 215L Programming Language II Lab");
				third1.getItems().add("CSE 173 Discrete Mathematics");
				third1.getItems().add("CSE 225 Data Structures and Algorithms");
				third1.getItems().add("CSE 225L Data Structures and Algorithms Lab");
				third1.getItems().add("CSE 231 Digital Logic design");
				third1.getItems().add("CSE 231L Digital Logic design Lab");
				third1.getItems().add("CSE 299 Junior Design Course");
				third1.getItems().add("EEE 141 Electrical Circuits I");
				third1.getItems().add("EEE 141L Electrical Circuits I Lab");
				third1.getItems().add("EEE 111/ ETE 111 Analog Electronics-I");
				third1.getItems().add("EEE 111L/ ETE 111L Analog Electronics-I Lab");
				third1.getItems().add("CSE 311 Database Systems");
				third1.getItems().add("CSE 311L Database Systems Lab");
				third1.getItems().add("CSE 323 Operating Systems Design");
				third1.getItems().add("CSE 327 Software Engineering");
				third1.getItems().add("CSE 331 Microprocessor Interfacing & Embedded System");
				third1.getItems().add("CSE 331L Microprocessor Interfacing & Embedded System Lab");
				third1.getItems().add("CSE 332 Computer Organization and Architecture");
				third1.getItems().add("CSE 373 Design and Analysis of Algorithms");
				third1.getItems().add("CSE 325/CSE 425 Concepts of Programming Language");
				third1.getItems().add("CSE 498/EEE 498/ETE 498 Internship/Co-op/Directed Research");
				third1.getItems().add("CSE 499A/EEE499A/ETE499A – Senior Design I");
				third1.getItems().add("CSE 499B/EEE499B/ETE499B – Senior Design II");
				third1.getItems().add("CSE 417 Numerical Methods");
				third1.getItems().add("CSE 401 Advanced Programming Techniques");
				third1.getItems().add("CSE 418 Computer Graphics");
				third1.getItems().add("CSE 426 Compiler Constructions");
				third1.getItems().add("CSE 473 Theory of Computation");
				third1.getItems().add("CSE 411 Advanced Database Systems");
				third1.getItems().add("CSE 424 Object-Oriented Software Developments");
				third1.getItems().add("CSE 427 Software Quality Assurances & Testing");
				third1.getItems().add("CSE 428 Software Process Management");
				third1.getItems().add("CSE 429 Software System Architecture");
				third1.getItems().add("CSE 492 Special Topics");
				third1.getItems().add("CSE 422 Modelling and Simulation");
				third1.getItems().add("CSE 438 Data Communication & Network");
				third1.getItems().add("CSE 482 Internet and Web Technology");
				third1.getItems().add("CSE 485 Digital Signal Processing");
				third1.getItems().add("CSE 486 Mobile and Wireless Application Development");
				third1.getItems().add("CSE 493 Special Topics");
				third1.getItems().add("CSE 433 Advanced Computer Architecture");
				third1.getItems().add("CSE 435 Introduction to VLSI Design");
				third1.getItems().add("CSE 413 Verilog HDL: Modelling, Simulation and synthesis");
				third1.getItems().add("CSE 414 Advanced Chip Design Methodology and Optimiza.using HDL");
				third1.getItems().add("CSE 494 Special Topics");
				third1.getItems().add("CSE 419 Data Mining");
				third1.getItems().add("CSE 440 Artificial Intelligence");
				third1.getItems().add("CSE 445 Machine Learning");
				third1.getItems().add("CSE 465 Pattern Recognition and Neural Network");
				third1.getItems().add("CSE 467 Digital Image Processing");
				third1.getItems().add("CSE 468 Computer Vision");
				third1.getItems().add("CSE 470 Theory of Fuzzy Systems");
				third1.getItems().add("CSE 495 Special Topics");
				third1.getItems().add("CSE 446 Introductions to Bioinformatics");
				third1.getItems().add("CSE 447 Molecular Biology");
				third1.getItems().add("CSE 448 Genome Sequence & Analysis");
				third1.getItems().add("CSE 449 Structural Bioinformatics");
				third1.getItems().add("CSE 496 Special Topics");
				
				
				
				Label cr3=new Label("Credit");
				ComboBox<String> third2=new ComboBox<String>();
				third2.getItems().add("0");
				third2.getItems().add("1");
				third2.getItems().add("1.5");
				third2.getItems().add("3");
				
				Label grd3=new Label("Grade");
				ComboBox<String> third3=new ComboBox<String>();
				
				
				third3.getItems().add("A");
				third3.getItems().add("A-");
				third3.getItems().add("B+");
				third3.getItems().add("B");
				third3.getItems().add("B-");
				third3.getItems().add("C+");
				third3.getItems().add("C");
				third3.getItems().add("C-");
				third3.getItems().add("D+");
				third3.getItems().add("D");
				third3.getItems().add("F");
				third3.getItems().add("NONE");
				
				////////////////
				////////////////
				
				Label crs4=new Label("Course 4: ");	
				Label nm4=new Label("name");
				ComboBox<String> fourth1=new ComboBox<String>();
				
				fourth1.getItems().add("NONE");
				fourth1.getItems().add("ENG 102 Introduction to Composition");
			    fourth1.getItems().add("ENG 103 Intermediate Composition");
				fourth1.getItems().add("ENG 111 Public Speaking");
				fourth1.getItems().add("PHI 101 Introduction to Philosophy");
				fourth1.getItems().add("PHI 104 Introduction to Ethics");
				fourth1.getItems().add("LBA 101 Bangladesh Culture and Heritage");
				fourth1.getItems().add("LBA 102 Introduction to World Civilization");
				fourth1.getItems().add("POL 101 Introduction to Political Science");
				fourth1.getItems().add("POL 104 Introduction to Governance");
				fourth1.getItems().add("ECO 101 Introduction to Microeconomics");
				fourth1.getItems().add("ECO 104 Introduction to Macroeconomics");
				fourth1.getItems().add("SOC 101 Introduction to Sociology");
				fourth1.getItems().add("ENV 203/ GEO 205 Introduction to Bangladesh Geography");
				fourth1.getItems().add("ANT 101 Introduction to Anthropology");
				fourth1.getItems().add("BIO 103 Biology I");
				fourth1.getItems().add("MAT 116 Pre-Calculus");
				fourth1.getItems().add("MAT 120 Calculus-I");
				fourth1.getItems().add("MAT 125 Linear Algebra");
				fourth1.getItems().add("MAT 130 Calculus II");
				fourth1.getItems().add("MAT 250 Calculus III");
				fourth1.getItems().add("MAT 350 Engineering Mathematics");
				fourth1.getItems().add("MAT 361 Probability and Statistics");
				fourth1.getItems().add("PHY 107 Physics I");
				fourth1.getItems().add("PHY 108 Physics II");
				fourth1.getItems().add("CHE 101 Chemistry I");
				fourth1.getItems().add("EEE 452 Engineering Economics");
				fourth1.getItems().add("CEE 110 Engineering Drawing (EEE 154)");
				fourth1.getItems().add("CSE 115 Programming Language I");
				fourth1.getItems().add("CSE 115L Programming Language I Lab");
				fourth1.getItems().add("CSE 215 Programming Language II");
				fourth1.getItems().add("CSE 215L Programming Language II Lab");
				fourth1.getItems().add("CSE 173 Discrete Mathematics");
				fourth1.getItems().add("CSE 225 Data Structures and Algorithms");
				fourth1.getItems().add("CSE 225L Data Structures and Algorithms Lab");
				fourth1.getItems().add("CSE 231 Digital Logic design");
				fourth1.getItems().add("CSE 231L Digital Logic design Lab");
				fourth1.getItems().add("CSE 299 Junior Design Course");
				fourth1.getItems().add("EEE 141 Electrical Circuits I");
				fourth1.getItems().add("EEE 141L Electrical Circuits I Lab");
				fourth1.getItems().add("EEE 111/ ETE 111 Analog Electronics-I");
				fourth1.getItems().add("EEE 111L/ ETE 111L Analog Electronics-I Lab");
				fourth1.getItems().add("CSE 311 Database Systems");
				fourth1.getItems().add("CSE 311L Database Systems Lab");
				fourth1.getItems().add("CSE 323 Operating Systems Design");
				fourth1.getItems().add("CSE 327 Software Engineering");
				fourth1.getItems().add("CSE 331 Microprocessor Interfacing & Embedded System");
				fourth1.getItems().add("CSE 331L Microprocessor Interfacing & Embedded System Lab");
				fourth1.getItems().add("CSE 332 Computer Organization and Architecture");
				fourth1.getItems().add("CSE 373 Design and Analysis of Algorithms");
				fourth1.getItems().add("CSE 325/CSE 425 Concepts of Programming Language");
				fourth1.getItems().add("CSE 498/EEE 498/ETE 498 Internship/Co-op/Directed Research");
				fourth1.getItems().add("CSE 499A/EEE499A/ETE499A – Senior Design I");
				fourth1.getItems().add("CSE 499B/EEE499B/ETE499B – Senior Design II");
				fourth1.getItems().add("CSE 417 Numerical Methods");
				fourth1.getItems().add("CSE 401 Advanced Programming Techniques");
				fourth1.getItems().add("CSE 418 Computer Graphics");
				fourth1.getItems().add("CSE 426 Compiler Constructions");
				fourth1.getItems().add("CSE 473 Theory of Computation");
				fourth1.getItems().add("CSE 411 Advanced Database Systems");
				fourth1.getItems().add("CSE 424 Object-Oriented Software Developments");
				fourth1.getItems().add("CSE 427 Software Quality Assurances & Testing");
				fourth1.getItems().add("CSE 428 Software Process Management");
				fourth1.getItems().add("CSE 429 Software System Architecture");
				fourth1.getItems().add("CSE 492 Special Topics");
				fourth1.getItems().add("CSE 422 Modelling and Simulation");
				fourth1.getItems().add("CSE 438 Data Communication & Network");
				fourth1.getItems().add("CSE 482 Internet and Web Technology");
				fourth1.getItems().add("CSE 485 Digital Signal Processing");
				fourth1.getItems().add("CSE 486 Mobile and Wireless Application Development");
				fourth1.getItems().add("CSE 493 Special Topics");
				fourth1.getItems().add("CSE 433 Advanced Computer Architecture");
				fourth1.getItems().add("CSE 435 Introduction to VLSI Design");
				fourth1.getItems().add("CSE 413 Verilog HDL: Modelling, Simulation and synthesis");
				fourth1.getItems().add("CSE 414 Advanced Chip Design Methodology and Optimiza.using HDL");
				fourth1.getItems().add("CSE 494 Special Topics");
				fourth1.getItems().add("CSE 419 Data Mining");
				fourth1.getItems().add("CSE 440 Artificial Intelligence");
				fourth1.getItems().add("CSE 445 Machine Learning");
				fourth1.getItems().add("CSE 465 Pattern Recognition and Neural Network");
				fourth1.getItems().add("CSE 467 Digital Image Processing");
				fourth1.getItems().add("CSE 468 Computer Vision");
				fourth1.getItems().add("CSE 470 Theory of Fuzzy Systems");
				fourth1.getItems().add("CSE 495 Special Topics");
				fourth1.getItems().add("CSE 446 Introductions to Bioinformatics");
				fourth1.getItems().add("CSE 447 Molecular Biology");
				fourth1.getItems().add("CSE 448 Genome Sequence & Analysis");
				fourth1.getItems().add("CSE 449 Structural Bioinformatics");
				fourth1.getItems().add("CSE 496 Special Topics");
				
				
				
				Label cr4=new Label("Credit");
				ComboBox<String> fourth2=new ComboBox<String>();
				fourth2.getItems().add("0");
				fourth2.getItems().add("1");
				fourth2.getItems().add("1.5");
				fourth2.getItems().add("3");
				
				Label grd4=new Label("Grade");
				ComboBox<String> fourth3=new ComboBox<String>();
				
				
				fourth3.getItems().add("A");
				fourth3.getItems().add("A-");
				fourth3.getItems().add("B+");
				fourth3.getItems().add("B");
				fourth3.getItems().add("B-");
				fourth3.getItems().add("C+");
				fourth3.getItems().add("C");
				fourth3.getItems().add("C-");
				fourth3.getItems().add("D+");
				fourth3.getItems().add("D");
				fourth3.getItems().add("F");
				fourth3.getItems().add("NONE");
				
				
				//////////////////
				//////////////////
				
				Label crs5=new Label("Course 5: ");	
				Label nm5=new Label("name");
				ComboBox<String> fifth1=new ComboBox<String>();
				
				fifth1.getItems().add("NONE");
				fifth1.getItems().add("ENG 102 Introduction to Composition");
			    fifth1.getItems().add("ENG 103 Intermediate Composition");
				fifth1.getItems().add("ENG 111 Public Speaking");
				fifth1.getItems().add("PHI 101 Introduction to Philosophy");
				fifth1.getItems().add("PHI 104 Introduction to Ethics");
				fifth1.getItems().add("LBA 101 Bangladesh Culture and Heritage");
				fifth1.getItems().add("LBA 102 Introduction to World Civilization");
				fifth1.getItems().add("POL 101 Introduction to Political Science");
				fifth1.getItems().add("POL 104 Introduction to Governance");
				fifth1.getItems().add("ECO 101 Introduction to Microeconomics");
				fifth1.getItems().add("ECO 104 Introduction to Macroeconomics");
				fifth1.getItems().add("SOC 101 Introduction to Sociology");
				fifth1.getItems().add("ENV 203/ GEO 205 Introduction to Bangladesh Geography");
				fifth1.getItems().add("ANT 101 Introduction to Anthropology");
				fifth1.getItems().add("BIO 103 Biology I");
				fifth1.getItems().add("MAT 116 Pre-Calculus");
				fifth1.getItems().add("MAT 120 Calculus-I");
				fifth1.getItems().add("MAT 125 Linear Algebra");
				fifth1.getItems().add("MAT 130 Calculus II");
				fifth1.getItems().add("MAT 250 Calculus III");
				fifth1.getItems().add("MAT 350 Engineering Mathematics");
				fifth1.getItems().add("MAT 361 Probability and Statistics");
				fifth1.getItems().add("PHY 107 Physics I");
				fifth1.getItems().add("PHY 108 Physics II");
				fifth1.getItems().add("CHE 101 Chemistry I");
				fifth1.getItems().add("EEE 452 Engineering Economics");
				fifth1.getItems().add("CEE 110 Engineering Drawing (EEE 154)");
				fifth1.getItems().add("CSE 115 Programming Language I");
				fifth1.getItems().add("CSE 115L Programming Language I Lab");
				fifth1.getItems().add("CSE 215 Programming Language II");
				fifth1.getItems().add("CSE 215L Programming Language II Lab");
				fifth1.getItems().add("CSE 173 Discrete Mathematics");
				fifth1.getItems().add("CSE 225 Data Structures and Algorithms");
				fifth1.getItems().add("CSE 225L Data Structures and Algorithms Lab");
				fifth1.getItems().add("CSE 231 Digital Logic design");
				fifth1.getItems().add("CSE 231L Digital Logic design Lab");
				fifth1.getItems().add("CSE 299 Junior Design Course");
				fifth1.getItems().add("EEE 141 Electrical Circuits I");
				fifth1.getItems().add("EEE 141L Electrical Circuits I Lab");
				fifth1.getItems().add("EEE 111/ ETE 111 Analog Electronics-I");
				fifth1.getItems().add("EEE 111L/ ETE 111L Analog Electronics-I Lab");
				fifth1.getItems().add("CSE 311 Database Systems");
				fifth1.getItems().add("CSE 311L Database Systems Lab");
				fifth1.getItems().add("CSE 323 Operating Systems Design");
				fifth1.getItems().add("CSE 327 Software Engineering");
				fifth1.getItems().add("CSE 331 Microprocessor Interfacing & Embedded System");
				fifth1.getItems().add("CSE 331L Microprocessor Interfacing & Embedded System Lab");
				fifth1.getItems().add("CSE 332 Computer Organization and Architecture");
				fifth1.getItems().add("CSE 373 Design and Analysis of Algorithms");
				fifth1.getItems().add("CSE 325/CSE 425 Concepts of Programming Language");
				fifth1.getItems().add("CSE 498/EEE 498/ETE 498 Internship/Co-op/Directed Research");
				fifth1.getItems().add("CSE 499A/EEE499A/ETE499A – Senior Design I");
				fifth1.getItems().add("CSE 499B/EEE499B/ETE499B – Senior Design II");
				fifth1.getItems().add("CSE 417 Numerical Methods");
				fifth1.getItems().add("CSE 401 Advanced Programming Techniques");
				fifth1.getItems().add("CSE 418 Computer Graphics");
				fifth1.getItems().add("CSE 426 Compiler Constructions");
				fifth1.getItems().add("CSE 473 Theory of Computation");
				fifth1.getItems().add("CSE 411 Advanced Database Systems");
				fifth1.getItems().add("CSE 424 Object-Oriented Software Developments");
				fifth1.getItems().add("CSE 427 Software Quality Assurances & Testing");
				fifth1.getItems().add("CSE 428 Software Process Management");
				fifth1.getItems().add("CSE 429 Software System Architecture");
				fifth1.getItems().add("CSE 492 Special Topics");
				fifth1.getItems().add("CSE 422 Modelling and Simulation");
				fifth1.getItems().add("CSE 438 Data Communication & Network");
				fifth1.getItems().add("CSE 482 Internet and Web Technology");
				fifth1.getItems().add("CSE 485 Digital Signal Processing");
				fifth1.getItems().add("CSE 486 Mobile and Wireless Application Development");
				fifth1.getItems().add("CSE 493 Special Topics");
				fifth1.getItems().add("CSE 433 Advanced Computer Architecture");
				fifth1.getItems().add("CSE 435 Introduction to VLSI Design");
				fifth1.getItems().add("CSE 413 Verilog HDL: Modelling, Simulation and synthesis");
				fifth1.getItems().add("CSE 414 Advanced Chip Design Methodology and Optimiza.using HDL");
				fifth1.getItems().add("CSE 494 Special Topics");
				fifth1.getItems().add("CSE 419 Data Mining");
				fifth1.getItems().add("CSE 440 Artificial Intelligence");
				fifth1.getItems().add("CSE 445 Machine Learning");
				fifth1.getItems().add("CSE 465 Pattern Recognition and Neural Network");
				fifth1.getItems().add("CSE 467 Digital Image Processing");
				fifth1.getItems().add("CSE 468 Computer Vision");
				fifth1.getItems().add("CSE 470 Theory of Fuzzy Systems");
				fifth1.getItems().add("CSE 495 Special Topics");
				fifth1.getItems().add("CSE 446 Introductions to Bioinformatics");
				fifth1.getItems().add("CSE 447 Molecular Biology");
				fifth1.getItems().add("CSE 448 Genome Sequence & Analysis");
				fifth1.getItems().add("CSE 449 Structural Bioinformatics");
				fifth1.getItems().add("CSE 496 Special Topics");
				fifth1.getItems().add("NONE");
				
				
				Label cr5=new Label("Credit");
				ComboBox<String> fifth2=new ComboBox<String>();
				fifth2.getItems().add("0");
				fifth2.getItems().add("1");
				fifth2.getItems().add("1.5");
				fifth2.getItems().add("3");
				
				Label grd5=new Label("Grade");
				ComboBox<String> fifth3=new ComboBox<String>();
				
				
				fifth3.getItems().add("A");
				fifth3.getItems().add("A-");
				fifth3.getItems().add("B+");
				fifth3.getItems().add("B");
				fifth3.getItems().add("B-");
				fifth3.getItems().add("C+");
				fifth3.getItems().add("C");
				fifth3.getItems().add("C-");
				fifth3.getItems().add("D+");
				fifth3.getItems().add("D");
				fifth3.getItems().add("F");
				fifth3.getItems().add("NONE");
				
				//////////////
				//////////////
				
				
			Button calculate=new Button("CALCULATE");
			
			
			
			calculate.setOnAction(new EventHandler<ActionEvent>() {

				
				public void handle(ActionEvent arg0) {
					
					
					
					double cgpa,total_credit,sumation;
					
					
					
					double c1=Double.parseDouble(first2.getValue());
					double c2=Double.parseDouble(second2.getValue());
					double c3=Double.parseDouble(third2.getValue());
					double c4=Double.parseDouble(fourth2.getValue());
					double c5=Double.parseDouble(fifth2.getValue());
					
					
					double g1=coGrade(first3.getValue());
					double g2=coGrade(second3.getValue());
					double g3=coGrade(third3.getValue());
					double g4=coGrade(fourth3.getValue());
					double g5=coGrade(fifth3.getValue());
					
				
					total_credit=c1+c2+c3+c4+c5;
					
					sumation=c1*g1+c2*g2+c3*g3+c4*g4+c5*g5;
					
					cgpa=sumation/total_credit;
					
					
					
					String nam=t1.getText().toString();
					String id=t2.getText().toString();
				
					
					DecimalFormat df=new DecimalFormat("0.##");
					
					
					File ob=new File("cgpa_calculator.txt");
					
					
					try {
						ob.createNewFile();
						
						   FileWriter fr=new FileWriter("cgpa_calculator.txt");
						   
						   fr.write("Name :"+nam+"Id :"+id);
						   fr.write("\nCOURSE NAME :"+first1.getValue()+"   "+"CREDIT :"+first2.getValue()+"   "+"GRADE :"+first3.getValue());
						   fr.write("\nCOURSE NAME :"+second1.getValue()+"   "+"CREDIT :"+second2.getValue()+"   "+"GRADE :"+second3.getValue());
						   fr.write("\nCOURSE NAME :"+third1.getValue()+"   "+"CREDIT :"+third2.getValue()+"   "+"GRADE :"+third3.getValue());
						   fr.write("\nCOURSE NAME :"+fourth1.getValue()+"   "+"CREDIT :"+fourth2.getValue()+"   "+"GRADE :"+fourth3.getValue());
						   fr.write("\nCOURSE NAME :"+fifth1.getValue()+"   "+"CREDIT :"+fifth2.getValue()+"   "+"GRADE :"+fifth3.getValue());
						   fr.write("\nCGPA :"+df.format(cgpa));
						   fr.close();
						
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				
					
					
					
					Alert al=new Alert(AlertType.CONFIRMATION);
					al.setContentText("Name :" +nam +"  ID :"+id.toString()+ "\nCourse 1 :"+first1.getValue().toString()+"\nCourse credit :"+first2.getValue().toString()+"\nGrade :"+first3.getValue().toString()+"\nCourse 2 :"+second1.getValue().toString()+"\nCourse credit :"+second2.getValue().toString()+"\nGrade :"+second3.getValue().toString()+"\nCourse 3 :"+third1.getValue().toString()+"\nCourse credit :"+third2.getValue().toString()+"\nGrade :"+third3.getValue().toString()+"\nCourse 4 :"+fourth1.getValue().toString()+"\nCourse credit :"+fourth2.getValue().toString()+"\nGrade :"+fourth3.getValue().toString()+"\nCourse 5 :"+first1.getValue().toString()+"\nCourse credit :"+first2.getValue().toString()+"\nGrade :"+first3.getValue().toString()+"\n\n\n Total CGPA = "+df.format(cgpa));
				
					al.setTitle("Message");
					al.setHeaderText("Data");
					al.show();
					
					
					}
			});
				
			HBox hb1=new HBox(10,crs1,nm1,first1,cr1,first2,grd1,first3);
			HBox hb2=new HBox(10,crs2,nm2,second1,cr2,second2,grd2,second3);
			HBox hb3=new HBox(10,crs3,nm3,third1,cr3,third2,grd3,third3);
			HBox hb4=new HBox(10,crs4,nm4,fourth1,cr4,fourth2,grd4,fourth3);
			HBox hb5=new HBox(10,crs5,nm5,fifth1,cr5,fifth2,grd5,fifth3);
			HBox hb6=new HBox(calculate);
			hb6.setAlignment(Pos.CENTER);
			HBox hb7=new HBox(15,stdName,t1,stdId,t2);
			hb7.setAlignment(Pos.CENTER);
			
			
			VBox vb=new VBox(15,hb7,hb1,hb2,hb3,hb4,hb5,hb6);
			VBox vb1=new VBox(35,head,vb);
			vb1.setAlignment(Pos.CENTER);
			
			
			vb.setAlignment(Pos.TOP_CENTER);
			
			Scene scene=new Scene(vb1,800,500);
			

			pstage.setScene(scene);
			pstage.setTitle("CGPA Calculator");
			pstage.show();
				
				
			}
		});
		
		HBox str=new HBox(10,starter);
		
		str.setAlignment(Pos.CENTER);
		
		Scene scn=new Scene(str,300,300);
		
		pstage.setScene(scn);
		pstage.setTitle("CGPA Calculator");
		pstage.show();
		
		
		
		
	}
	
	
	public double coGrade(String fr3)
	{
		 
		if(fr3.equals("A"))
		{
			return 4.0;
			 
		} 
		if(fr3.equals("A-"))
		{
			return 3.7;
			 
		} 
		if(fr3.equals("B+"))
		{
			return 3.3;
			 
		}
		if(fr3.equals("B"))
		{
			return 3.0;
			 
		} 
		if(fr3.equals("B-"))
		{
			return 2.7;
			 
		}
		if(fr3.equals("C+"))
		{
			return 2.3;
			 
		}
		if(fr3.equals("C"))
		{
			return 2.0;
			 
		} 
		if(fr3.equals("C-"))
		{
			return 1.7;
			
		} 
		if(fr3.equals("D+"))
		{
			return 1.3;
			
		} 
		if(fr3.equals("D"))
		{
			return 1.0;
			
		} 
		if(fr3.equals("F"))
		{
			return 0.0;
			
		}else return 0.0;
	}
	
	public static void main(String[] args) {
		
		launch(args);

	}

	

}
